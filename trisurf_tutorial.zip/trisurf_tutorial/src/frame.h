/* vim: set ts=4 sts=4 sw=4 noet : */
#ifndef _H_FRAME
#define _H_FRAME
ts_bool centermass(ts_vesicle *vesicle);
ts_bool cell_occupation(ts_vesicle *vesicle);

#endif
